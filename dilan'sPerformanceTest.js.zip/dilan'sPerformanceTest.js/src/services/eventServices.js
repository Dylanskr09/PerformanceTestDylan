export const getAllEvents = async () => {
  const res = await fetch("http://localhost:3000/events");
  if (!res.ok) throw new Error("Error al obtener los eventos");
  return await res.json();
};

export const deleteEvent = async (id) => {
  const res = await fetch(`http://localhost:3000/events/${id}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Error al eliminar el evento");
};