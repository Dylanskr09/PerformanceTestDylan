<main class="container py-5 my-5">
  <section class="row justify-content-center">
    <div class="col-md-6">
      <h2 class="text-center mb-4">Iniciar Sesión</h2>
      <form id="loginForm" class="bg-light p-4 rounded shadow-sm">
        <div class="mb-3">
          <label for="email" class="form-label">Correo electrónico</label>
          <input type="email" class="form-control" id="email" placeholder="ej: admin@eventos.com" required />
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Contraseña</label>
          <input type="password" class="form-control" id="password" placeholder="Contraseña" required />
        </div>
        <button type="submit" class="btn btn-primary w-100">Ingresar</button>
        <div id="loginError" class="mt-3 text-danger text-center d-none"></div>
      </form>
    </div>
  </section>
</main>
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const errorMessage = document.getElementById("error-message");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorMessage.textContent = "";

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (!email || !password) {
      errorMessage.textContent = "Todos los campos son obligatorios.";
      return;
    }

    try {
      const res = await fetch("http://localhost:3000/users");
      if (!res.ok) throw new Error("Error al consultar usuarios");

      const users = await res.json();
      const userFound = users.find(
        (user) => user.email === email && user.password === password
      );

      if (!userFound) {
        errorMessage.textContent = "Correo o contraseña incorrectos.";
        return;
      }

      // Guardar sesión
      localStorage.setItem("user", JSON.stringify(userFound));

      // Redirigir según el rol
      switch (userFound.role) {
        case "admin":
          window.location.href = "/admin";
          break;
        case "editor":
          window.location.href = "/editor";
          break;
        case "viewer":
          window.location.href = "/viewer";
          break;
        default:
          window.location.href = "/";
      }
    } catch (err) {
      errorMessage.textContent = "Ocurrió un error en el login.";
      console.error(err);
    }
  });
});