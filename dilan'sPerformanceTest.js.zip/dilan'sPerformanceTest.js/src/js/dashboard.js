import { API_URL } from "../js/config.js";
import { getCurrentUser, redirectIfNotAllowed } from "./auth.js";

document.addEventListener("DOMContentLoaded", () => {
  redirectIfNotAllowed(["admin", "editor"]);

  const user = getCurrentUser();
  const form = document.getElementById("event-form");
  const tableBody = document.getElementById("events-table-body");
  const cancelBtn = document.getElementById("cancel-edit");
  const inputs = {
    id: document.getElementById("event-id"),
    title: document.getElementById("title"),
    date: document.getElementById("date"),
    description: document.getElementById("description"),
  };

  const loadEvents = async () => {
    const res = await fetch(`${API_URL}/events`);
    const data = await res.json();
    renderTable(data);
  };

  const renderTable = (events) => {
    tableBody.innerHTML = events.length
      ? events.map(event => 
        `<tr>
          <td>${event.title}</td>
          <td>${event.date}</td>
          <td>${event.description}</td>
          <td>
            <button class="btn btn-sm btn-warning edit" data-id="${event.id}">Editar</button>
            <button class="btn btn-sm btn-danger delete" data-id="${event.id}">Eliminar</button>
          </td>
        </tr>`
      ).join('')
      : `<tr><td colspan="4" class="text-center">No hay eventos registrados</td></tr>`;
  };

  const saveEvent = async (e) => {
    e.preventDefault();
    const event = {
      title: inputs.title.value.trim(),
      date: inputs.date.value,
      description: inputs.description.value.trim(),
    };

    const method = inputs.id.value ? "PUT" : "POST";
    const url = inputs.id.value
      ? `${API_URL}/events/${inputs.id.value}`
      : `${API_URL}/events`;

    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(event),
    });

    form.reset();
    inputs.id.value = "";
    cancelBtn.style.display = "none";
    document.getElementById("form-title").textContent = "Crear nuevo evento";
    loadEvents();
  };

  const handleActions = async (e) => {
    const id = e.target.dataset.id;
    if (e.target.classList.contains("edit")) {
      const data = await fetch(`${API_URL}/events/${id}`).then(r => r.json());
      inputs.title.value = data.title;
      inputs.date.value = data.date;
      inputs.description.value = data.description;
      inputs.id.value = data.id;
      document.getElementById("form-title").textContent = "Editar evento";
      cancelBtn.style.display = "inline-block";
    }

    if (e.target.classList.contains("delete")) {
      if (confirm("¿Eliminar este evento?")) {
        await fetch(`${API_URL}/events/${id}`, { method: "DELETE" });
        loadEvents();
      }
    }
  };

  const cancelEdit = () => {
    form.reset();
    inputs.id.value = "";
    cancelBtn.style.display = "none";
    document.getElementById("form-title").textContent = "Crear nuevo evento";
  };

  form.addEventListener("submit", saveEvent);
  cancelBtn.addEventListener("click", cancelEdit);
  tableBody.addEventListener("click", handleActions);

  loadEvents();
});