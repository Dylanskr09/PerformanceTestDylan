export function checkAuthAndRedirect(allowedRoles = []) {
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user || !allowedRoles.includes(user.role)) {
    alert("Acceso denegado. Inicia sesión con los permisos adecuados.");
    window.location.href = "/login";
    return null;
  }

  return user;
}