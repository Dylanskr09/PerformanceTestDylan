const root = document.getElementById("root");

const routes = {
  "/": {
    view: "pages/main.html",
    script: "views/main.js",
  },
  "/login": {
    view: "pages/login.html",
    script: "views/login.js",
  },
  "/dashboard": {
    view: "pages/dashboard.html",
    script: "views/dashboard.js",
  },
  "/viewer": {
    view: "pages/viewer.html",
    script: "views/viewer.js",
  }
};

const navigateTo = (url) => {
  history.pushState(null, null, url);
  router();
};

document.addEventListener("DOMContentLoaded", () => {
  document.body.addEventListener("click", (e) => {
    if (e.target.matches("[data-link]")) {
      e.preventDefault();
      navigateTo(e.target.href);
    }
  });
  router();
});

window.addEventListener("popstate", router);

async function router() {
  const path = window.location.pathname;
  const route = routes[path] || routes["/"];

  try {
    const res = await fetch(route.view);
    const html = await res.text();
    root.innerHTML = html;
    if (route.script) {
      const script = document.createElement("script");
      script.src = route.script;
      script.type = "module";
      document.body.appendChild(script);
    }
  } catch (error) {
    root.innerHTML = "<h2>Error cargando la vista</h2>";
    console.error(error);
  }
}

// Exportar navigateTo por si lo necesitas en otros scripts
export { navigateTo };