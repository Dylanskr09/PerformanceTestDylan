document.addEventListener("includes-loaded", () => {
  const user = JSON.parse(localStorage.getItem("user"));
  if (!user || user.role !== "editor") {
    window.location.href = "/login";
    return;
  }

  const API_URL = "http://localhost:3000/events";
  const eventForm = document.getElementById("eventForm");
  const eventList = document.getElementById("eventList");

  const title = document.getElementById("title");
  const location = document.getElementById("location");
  const date = document.getElementById("date");
  const description = document.getElementById("description");
  const eventId = document.getElementById("eventId");

  // Mostrar eventos existentes
  fetchEvents();

  // Guardar o actualizar evento
  eventForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const newEvent = {
      title: title.value,
      location: location.value,
      date: date.value,
      description: description.value,
    };

    if (eventId.value) {
      fetch(`${API_URL}/${eventId.value}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newEvent),
      }).then(() => {
        resetForm();
        fetchEvents();
      });
    } else {
      fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newEvent),
      }).then(() => {
        resetForm();
        fetchEvents();
      });
    }
  });

  function fetchEvents() {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => renderEvents(data));
  }

  function renderEvents(events) {
    eventList.innerHTML = "";
    if (events.length === 0) {
      eventList.innerHTML = `<p class="text-center">No hay eventos registrados.</p>`;
      return;
    }

    events.forEach((event) => {
      const col = document.createElement("div");
      col.className = "col-md-4";

      col.innerHTML = `
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">${event.title}</h5>
            <p class="card-text">${event.description}</p>
            <p><strong>Fecha:</strong> ${event.date}</p>
            <p><strong>Lugar:</strong> ${event.location}</p>
            <button class="btn btn-sm btn-outline-primary me-2" data-edit="${event.id}">Editar</button>
            <button class="btn btn-sm btn-outline-danger" data-delete="${event.id}">Eliminar</button>
          </div>
        </div>
      `;

      eventList.appendChild(col);
    });

    // Delegación para botones editar y eliminar
    eventList.querySelectorAll("[data-edit]").forEach((btn) => {
      btn.addEventListener("click", () => loadEventToForm(btn.dataset.edit));
    });

    eventList.querySelectorAll("[data-delete]").forEach((btn) => {
      btn.addEventListener("click", () => deleteEvent(btn.dataset.delete));
    });
  }

  function loadEventToForm(id) {
    fetch(`${API_URL}/${id}`)
      .then((res) => res.json())
      .then((event) => {
        title.value = event.title;
        location.value = event.location;
        date.value = event.date;
        description.value = event.description;
        eventId.value = event.id;
      });
  }

  function deleteEvent(id) {
    if (!confirm("¿Estás seguro de eliminar este evento?")) return;
    fetch(`${API_URL}/${id}`, { method: "DELETE" }).then(() => fetchEvents());
  }

  function resetForm() {
    eventForm.reset();
    eventId.value = "";
  }
});