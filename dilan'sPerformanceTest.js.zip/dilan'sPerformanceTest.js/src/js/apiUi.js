const apiUrl = "http://localhost:3000/events";
const eventList = document.getElementById("eventList");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");

document.addEventListener("DOMContentLoaded", () => {
  loadEvents();
});

searchBtn.addEventListener("click", () => {
  const query = searchInput.value.toLowerCase().trim();
  loadEvents(query);
});

async function loadEvents(searchQuery = "") {
  try {
    const res = await fetch(apiUrl);
    const events = await res.json();

    const filteredEvents = events.filter((event) => {
      const title = event.title?.toLowerCase() || "";
      const category = event.category?.toLowerCase() || "";
      return title.includes(searchQuery) || category.includes(searchQuery);
    });

    renderEvents(filteredEvents);
  } catch (error) {
    eventList.innerHTML = `
      <div class="col-12 text-center text-danger">
        <p><strong>Error al cargar eventos:</strong> ${error.message}</p>
      </div>`;
  }
}

function renderEvents(events) {
  if (events.length === 0) {
    eventList.innerHTML = `
      <div class="col-12 text-center">
        <p class="text-muted">No se encontraron eventos.</p>
      </div>`;
    return;
  }

  eventList.innerHTML = events
    .map((event) => {
      return `
      <div class="col-md-6 col-lg-4">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <h5 class="card-title">${event.title}</h5>
            <p class="card-text">${event.description || "Sin descripción"}</p>
            <p><strong>Categoría:</strong> ${event.category || "No especificada"}</p>
            <p><strong>Fecha:</strong> ${event.date || "Sin fecha"}</p>
          </div>
        </div>
      </div>`;
    })
    .join("");
}