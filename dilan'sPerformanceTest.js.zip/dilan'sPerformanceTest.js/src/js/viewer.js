document.addEventListener("includes-loaded", () => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user || user.role !== "viewer") {
    window.location.href = "/login";
    return;
  }

  fetch("http://localhost:3000/events")
    .then((res) => {
      if (!res.ok) throw new Error("No se pudieron obtener los eventos");
      return res.json();
    })
    .then((events) => renderViewerEvents(events))
    .catch((err) => {
      document.getElementById("viewerEventsContainer").innerHTML = <p class="text-danger">${err.message}</p>;
    });

  function renderViewerEvents(events) {
    const container = document.getElementById("viewerEventsContainer");
    container.innerHTML = "";

    if (events.length === 0) {
      container.innerHTML = <p class="text-center">No hay eventos disponibles.</p>;
      return;
    }

    events.forEach((event) => {
      const card = document.createElement("div");
      card.className = "col-md-4";
      card.innerHTML = 
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">${event.title}</h5>
            <p class="card-text">${event.description}</p>
            <p><strong>Fecha:</strong> ${event.date}</p>
            <p><strong>Lugar:</strong> ${event.location}</p>
          </div>
        </div>
      ;
      container.appendChild(card);
    });
  }
});