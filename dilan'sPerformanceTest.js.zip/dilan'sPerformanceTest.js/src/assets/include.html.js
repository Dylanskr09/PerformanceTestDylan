document.addEventListener("DOMContentLoaded", async (e) => {
    const $elements = document.querySelectorAll("[data-include]");
    let loadedCount = 0;
    const total = $elements.length;

    if (total === 0) {
        document.dispatchEvent(new Event("includes-loaded"));
        return;
    }

    for (const el of $elements) {
        const urlConsulta = el.getAttribute("data-include");
        try {
            const resConsulta = await fetch(urlConsulta);
            if (!resConsulta.ok) throw { status: resConsulta.status, statusText: resConsulta.statusText };
            const html = await resConsulta.text();
            el.innerHTML = html;
        } catch (error) {
            const mensaje = error.statusText || "Ocurrió un error";
            el.innerHTML = `<p class='text-danger'><b>Error: ${error.status} - ${mensaje}</b></p>`;
        } finally {
            loadedCount++;
            if (loadedCount === total) {
                document.dispatchEvent(new Event("includes-loaded"));
            }
        }
    }
});