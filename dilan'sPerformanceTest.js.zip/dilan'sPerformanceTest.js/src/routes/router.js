import { isAuthenticated, getUser } from "../js/auth.js";
import LoginView from "../views/login.js";
import HomeView from "../views/home.js";
import AboutView from "../views/about.js";
import AccessDenied from "../views/accessDenied.js";
import NotFound from "../views/notFound.js";
import ApiUiView from "../views/apiUi.js";

const routes = {
  "/": HomeView,
  "/about": AboutView,
  "/login": LoginView,
  "/apiUi": ApiUiView,
};

export const router = () => {
  const path = window.location.pathname;
  const app = document.getElementById("app");
  const view = routes[path] || NotFound;

  const user = getUser();

  const adminRoutes = ["/apiUi"];
  const authRoutes = ["/"];

  if (!user && authRoutes.includes(path)) {
    app.innerHTML = AccessDenied();
    return;
  }

  if (user && user.role !== "admin" && adminRoutes.includes(path)) {
    app.innerHTML = AccessDenied();
    return;
  }

  if (typeof view === "function") {
    app.innerHTML = view();
  }
};
