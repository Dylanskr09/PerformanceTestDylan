import { checkAuth, logout } from "/src/utils/auth.js";
import { getAllEvents, deleteEvent } from "/src/services/eventService.js";

document.addEventListener("DOMContentLoaded", async () => {
  const user = checkAuth();
  const eventsContainer = document.getElementById("eventsContainer");

  try {
    const events = await getAllEvents();

    if (events.length === 0) {
      eventsContainer.innerHTML = <p class="text-center">No hay eventos registrados.</p>;
      return;
    }

    eventsContainer.innerHTML = events
      .map((event) => {
        return 
        <div class="col-md-4">
          <div class="card h-100 shadow">
            <div class="card-body">
              <h5 class="card-title">${event.title}</h5>
              <h6 class="card-subtitle mb-2 text-muted">${event.date}</h6>
              <p class="card-text">${event.description}</p>
              <p><strong>Ubicación:</strong> ${event.location}</p>
              ${user && (user.role === "admin" || user.role === "editor") ? 
                <div class="d-flex justify-content-between">
                  <a href="/edit?id=${event.id}" data-link class="btn btn-sm btn-outline-success">Editar</a>
                  <button class="btn btn-sm btn-outline-danger" data-id="${event.id}" onclick="handleDelete(${event.id})">Eliminar</button>
                </div>
               : ""}
            </div>
          </div>
        </div>;
      })
      .join("");
  } catch (error) {
    console.error("Error cargando eventos", error);
    eventsContainer.innerHTML = <p class="text-danger">Error al cargar los eventos</p>;
  }

  document.getElementById("btnLogout")?.addEventListener("click", logout);
});

window.handleDelete = async (id) => {
  const confirmDelete = confirm("¿Estás seguro de que deseas eliminar este evento?");
  if (!confirmDelete) return;

  try {
    await deleteEvent(id);
    alert("✅ Evento eliminado");
    location.reload();
  } catch (error) {
    alert("❌ Error al eliminar el evento");
    console.error(error);
  }
};