import { createEvent } from "/src/services/eventService.js";
import { checkAuthAndRedirect } from "/src/utils/auth.js";

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("createEventForm");

  // Verificamos autenticación y permisos
  const user = checkAuthAndRedirect(["admin", "editor"]);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const newEvent = {
      title: document.getElementById("title").value.trim(),
      description: document.getElementById("description").value.trim(),
      date: document.getElementById("date").value,
      location: document.getElementById("location").value.trim(),
    };

    try {
      await createEvent(newEvent);
      alert("✅ Evento creado correctamente");
      window.location.href = "/"; // redirige al home
    } catch (err) {
      alert("❌ Error al crear el evento");
      console.error(err);
    }
  });
});