import { checkAuth, logout } from "/src/utils/auth.js";
import { getEventById, updateEvent } from "/src/services/eventService.js";

document.addEventListener("DOMContentLoaded", async () => {
  const user = checkAuth(["admin", "editor"]);
  if (!user) return;

  const form = document.getElementById("editEventForm");
  const urlParams = new URLSearchParams(window.location.search);
  const eventId = urlParams.get("id");

  if (!eventId) {
    alert("ID de evento no especificado");
    window.location.href = "/events";
    return;
  }

  try {
    const event = await getEventById(eventId);

    if (!event) {
      alert("Evento no encontrado");
      return;
    }

    form.eventId.value = event.id;
    form.title.value = event.title;
    form.date.value = event.date;
    form.location.value = event.location;
    form.description.value = event.description;

  } catch (error) {
    alert("Error cargando el evento");
    console.error(error);
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const updatedEvent = {
      title: form.title.value.trim(),
      date: form.date.value,
      location: form.location.value.trim(),
      description: form.description.value.trim(),
    };

    try {
      await updateEvent(eventId, updatedEvent);
      alert("✅ Evento actualizado correctamente");
      window.location.href = "/events";
    } catch (error) {
      alert("❌ Error al actualizar el evento");
      console.error(error);
    }
  });

  document.getElementById("btnLogout")?.addEventListener("click", logout);
});