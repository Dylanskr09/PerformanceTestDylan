import { checkAuth, logout } from "/src/utils/auth.js";

document.addEventListener("DOMContentLoaded", async () => {
  const user = checkAuth(["admin"]);
  if (!user) return;

  const container = document.getElementById("eventsContainer");

  const loadEvents = async () => {
    const res = await fetch("http://localhost:3000/events");
    const events = await res.json();

    if (!events.length) {
      container.innerHTML = <p class="text-center">No hay eventos registrados.</p>;
      return;
    }

    container.innerHTML = events
      .map(
        (event) => 
        <div class="col-md-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">${event.title}</h5>
              <p class="card-text"><strong>Fecha:</strong> ${event.date}</p>
              <p class="card-text"><strong>Ubicación:</strong> ${event.location}</p>
              <p class="card-text">${event.description}</p>
              <div class="mt-auto d-flex justify-content-between">
                <a href="/edit?id=${event.id}" class="btn btn-sm btn-primary" data-link>Editar</a>
                <button class="btn btn-sm btn-danger" onclick="deleteEvent(${event.id})">Eliminar</button>
              </div>
            </div>
          </div>
        </div>
      )
      .join("");
  };

  window.deleteEvent = async (id) => {
    if (!confirm("¿Estás seguro de eliminar este evento?")) return;
    await fetch(`http://localhost:3000/events/${id}, { method: "DELETE" }`);
    loadEvents();
  };

  loadEvents();

  document.getElementById("btnLogout")?.addEventListener("click", logout);
});