import { getAllEvents } from "/src/services/eventService.js";

document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("highlightedEvents");

  try {
    const events = await getAllEvents();
    const featured = events.slice(0, 3); // Muestra los 3 primeros

    if (featured.length === 0) {
      container.innerHTML = <p class="text-muted">No hay eventos para mostrar.</p>;
      return;
    }

    container.innerHTML = featured
      .map((event) => 
        <div class="col-md-4">
          <div class="card shadow h-100">
            <div class="card-body">
              <h5 class="card-title">${event.title}</h5>
              <h6 class="card-subtitle mb-2 text-muted">${event.date}</h6>
              <p class="card-text">${event.description}</p>
              <p><strong>Ubicación:</strong> ${event.location}</p>
            </div>
          </div>
        </div>
      )
      .join("");
  } catch (error) {
    container.innerHTML = <p class="text-danger">Error al cargar los eventos destacados.</p>;
    console.error(error);
  }
});