# Gestor de Eventos - README

## Descripción

Este proyecto es una aplicación web para la gestión de eventos, con roles de usuario (admin, editor, viewer), autenticación, panel de administración, edición y eliminación de eventos. Utiliza HTML, CSS (Bootstrap), JavaScript y una API REST simulada (por ejemplo, con JSON Server).

## Estructura principal

- `/src/views/`  
  Contiene las vistas HTML principales (`login.html`, `main.html`, etc.).
- `/src/assets/`  
  Incluye archivos compartidos como `header.html`, `footer.html` y scripts utilitarios.
- `/src/controller/`  
  Lógica de control para cada vista (`admin.js`, `edit.js`, `login.js`).
- `/src/services/`  
  Funciones para interactuar con la API (`eventServices.js`).
- `/src/js/`  
  Utilidades generales (`auth.js`, `config.js`).

## Funcionalidades implementadas

- **Login y autenticación por roles**  
  Los usuarios se autentican y son redirigidos según su rol.
- **Panel de administración**  
  Permite crear, editar y eliminar eventos.
- **Includes dinámicos**  
  El header y el footer se cargan dinámicamente en cada página.
- **Rutas absolutas**  
  Los enlaces funcionan correctamente desde cualquier vista.
- **Servicios para eventos**  
  Funciones para obtener, actualizar y eliminar eventos desde la API.

## Lo que le falta al código

- **Integración y uso de `crypto`**
  - Si se requiere cifrado, hashing de contraseñas o generación de tokens, aún no está implementado.
  - Debes decidir si usarás `crypto` de Node.js (solo backend) o la Web Crypto API (en el navegador).
- **Validaciones más robustas**
  - Validar formularios tanto en frontend como en backend.
- **Manejo de errores y mensajes de usuario**
  - Mejorar la experiencia de usuario ante errores de red o validación.
- **Protección de rutas en frontend**
  - Asegurarse de que los usuarios no puedan acceder a páginas restringidas manipulando la URL.
- **Despliegue y configuración**
  - Instrucciones para correr el backend (por ejemplo, JSON Server) y el frontend.
- **Pruebas unitarias**
  - No hay tests automatizados para los servicios o controladores.
- **Documentación de endpoints**
  - Explicar qué endpoints espera el frontend y cómo debe responder el backend.
- **Mejorar la gestión de sesiones**
  - Actualmente se usa `localStorage`, pero sería recomendable usar tokens JWT y expiración de sesión para mayor seguridad.

## Cómo ejecutar el proyecto

1. Instala las dependencias necesarias (por ejemplo, JSON Server para la API REST).
2. Ejecuta el backend:
   ```bash
   npx json-server --watch db.json --port 3000
   ```
3. Abre `index.html` en tu navegador o usa una extensión de servidor local para servir los archivos.
4. Accede a `/src/views/login.html` para iniciar sesión.

## Notas

- Asegúrate de que todas las rutas en los enlaces y scripts sean absolutas y coincidan con la estructura de carpetas.
- Si necesitas usar `crypto`, revisa en qué entorno lo vas a usar y cómo importarlo correctamente.

---

**Colabora o reporta problemas abriendo un issue o un pull request.**